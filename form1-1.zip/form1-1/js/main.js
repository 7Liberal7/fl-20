// $(function() {
//   $('.date').datepicker({
//     changeMonth: true,
//     changeYear: true,
//     dateFormat: "yy-mm-dd",
//     firstDay: 1,
//   });
// });